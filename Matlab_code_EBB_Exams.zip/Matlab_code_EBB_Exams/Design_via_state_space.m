clc;
clear all;
s=tf('s');
syms s k1 k2 k3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Testing if thw plant is controllable %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


A = [-5 -4 0; 1 0 0; 1 1 0]
B = [1;0;0]
C = [0 1 2]
D = 0


% For 3x3 matrix

Cm = [B A*B A^2*B]
x1 = det(Cm)
if  x1 ~= 0
    disp('The Plant is Controllable')
end  



%The poles and zeros of the plant can be determined from the transfer function:


I=eye(3,3)

x=(s*I-A) %(sI-A)
y=det(x)  %det(sI-A)
z=inv((s*I-A))


G =( simplify( C*(inv(x))*B))

[num,den]=ss2tf(A,B,C,D,1)

roots(den)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%  Calculate the gains [?1 ?2 k3] %%%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Gs = -520*(s+0.02)/(s^3+2.64*s^2+0.109*s+0.013)

A_dot = [0 1 0; 0 0 1; -0.13 -0.109 -2.64 ]

B_dot = [0;0;1]

C_dot = [0.02 1 0]

D_dot = [0]

k = [k1 k2 k3]

Acl = A_dot - B_dot*k

