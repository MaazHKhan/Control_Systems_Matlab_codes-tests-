K=[l: 1:2000];
for n = l : length(K);
    dent=[l 18 77K{n)];
    poles = roots(dent); 
    r = real(poles);
        if max (r) > = 0,
            poles
    
    