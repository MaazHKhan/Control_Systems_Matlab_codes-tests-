clc;
clear all;
syms s x y;
syms k;
% s = tf('s');
s = tf('s');

sys = (s+2)/(s^3+5*s+2)
con = (1*(s+19.33)*(s+0.1))/s
G = (s+2)/(s^3+5*s+2)
% closed_loop = feedback(sys,1)

% 
% new = 4.726/(s^2+3*s+4.726)
% 
% P = pole(new)
% margin(new)
rlocus(sys*con)

% eq = (x+2)*(3x^2+18*x-10)
% factor(eq,x)
